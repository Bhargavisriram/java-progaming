package com.tnsif.oopsconcepts;

public class Creatingcandm {
	public void display(int a) {
		
		System.out.println("the valuse of the a is " +a);
	}
	public static void main(String[] args) {
		Creatingcandm s=new Creatingcandm();
		s.display(1);
	}
}
