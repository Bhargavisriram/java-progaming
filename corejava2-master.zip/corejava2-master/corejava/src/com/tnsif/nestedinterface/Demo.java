package com.tnsif.nestedinterface;

public class Demo {
	public static void main(String[] args) {
		Nestedinterface n=new Nestedinterface();
		n.print();
		System.out.println(n.id);
		System.out.println(Nestedinterface.id);
	}

}
