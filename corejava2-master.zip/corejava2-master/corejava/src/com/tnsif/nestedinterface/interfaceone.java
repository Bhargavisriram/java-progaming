package com.tnsif.nestedinterface;

public interface interfaceone {
	void print();

}

