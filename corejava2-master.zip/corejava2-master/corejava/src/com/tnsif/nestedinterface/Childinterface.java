package com.tnsif.nestedinterface;

public interface Childinterface {
	void show();

}
