package com.tnsif.nestedinterface;

public interface Myinterface {
	void calucatearea();
	interface Myinnerinterface{
		int id=30;
		void print();
		
	}

}
