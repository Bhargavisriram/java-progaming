package com.tnsif.junitprogram;

public class Demotwo {
public  int add(int a,int b) {
	return(a+b);
}
}
