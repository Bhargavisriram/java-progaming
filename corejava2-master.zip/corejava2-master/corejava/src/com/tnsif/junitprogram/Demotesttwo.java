package com.tnsif.junitprogram;
import static org.junit.Assert.assertTrue;
import org.junit.jupiter.parameterize
public class Demotesttwo {

}
