package com.tnsif.stringdemo;

public class Equalequalop {
	public static void main(String[] args) {
		String s1="guru";
		String s2="guru";
		String s3=new String("guru");
		System.out.println(s1==s2);
		System.out.println(s1==s3);
	}

}
