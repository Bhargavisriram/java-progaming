package com.tnsif.stringdemo;

public class Equals2 {
	public static void main(String[] args) {
		String s1="model";
		String s2="model";
		System.out.println(s1.equals(s2));
	}

}
