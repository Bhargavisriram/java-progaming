package com.tnsif.stringdemo;

public class Equals1 {
	public static void main(String[] args) {
		String s1="GURU";
		String s2="guru";
		System.out.println(s1.equals(s2));
		System.out.println(s1.equalsIgnoreCase(s2));
	}

}
