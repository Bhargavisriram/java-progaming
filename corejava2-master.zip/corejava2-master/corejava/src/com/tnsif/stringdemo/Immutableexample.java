package com.tnsif.stringdemo;

public class Immutableexample {
	public static void main(String[] args) {
		String s="sachin";
		s=s.concat("tendulkar");
		
		System.out.println(s);
	}

}
