package com.tnsif.lambdaexpressions;

public class Withlambda {
	public static void main(String[] args) {
		Myinterfacetwo ob=()->{System.out.println("welcome to lambda class");};
		
		ob.show();
	}

}
