package com.tnsif.lambdaexpressions;

public interface Cube {
	int cal(int a);

}
