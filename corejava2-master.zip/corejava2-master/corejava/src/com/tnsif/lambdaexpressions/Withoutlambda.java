package com.tnsif.lambdaexpressions;

public class Withoutlambda implements Myinterface {

	@Override
	public void display() {
		System.out.println("welcom to without lambda class");
		// TODO Auto-generated method stub
		
	}
	
}
