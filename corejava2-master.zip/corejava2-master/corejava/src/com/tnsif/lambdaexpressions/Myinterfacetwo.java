package com.tnsif.lambdaexpressions;

public interface Myinterfacetwo {
	public void show();

}
