package com.tnsif.lambdaexpressions;

public class Demo {
public static void main(String[] args) {
	Withoutlambda v=new Withoutlambda ();
	v.display();
	
}
}
