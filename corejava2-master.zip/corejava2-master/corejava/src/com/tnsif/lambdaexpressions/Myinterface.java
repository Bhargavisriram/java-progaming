package com.tnsif.lambdaexpressions;

public interface Myinterface {
	public void display(); 
 
		
	}


