package com.tnsif.collection;

import java.util.TreeSet;

public class Treesetdemo {
	public static void treesetoperations() {
		TreeSet<Integer> t=new TreeSet<Integer>();
		t.add(1);
		t.add(3);
		t.add(4);
		t.add(5);
		//t.add();
		System.out.println("elements of treeset"+t);
	}
public static void main(String[] args) {
	Treesetdemo.treesetoperations();
}
}
