package com.tnsif.collection;

public class Collectiondemo {
public static void main(String[] args) {
Setoperations s=new Setoperations();
s.operatioins();
}
}
