package com.tnsif.exceptionhandling;

public class Nesteddemo {
public static void main(String[] args) {
	Nestedtrycatchblock.check();
}
}
