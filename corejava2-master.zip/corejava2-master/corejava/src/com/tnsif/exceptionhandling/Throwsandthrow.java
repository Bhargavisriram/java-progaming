package com.tnsif.exceptionhandling;

public class Throwsandthrow {

}
