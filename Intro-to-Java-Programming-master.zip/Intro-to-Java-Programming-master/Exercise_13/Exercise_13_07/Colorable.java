public interface Colorable {
	/** Describe how to color */
	String howToColor();
}