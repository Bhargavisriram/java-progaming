/*
(Area and perimeter of a rectangle) Write a program that displays the area and
perimeter of a rectangle with the width of 4.5 and height of 7.9 using the following
formula:
						area = width * height
*/
public class Exercise_01_09 {
	public static void main(String[] args) {
		System.out.println("Area = ");
		System.out.println(4.5 * 7.9);
		System.out.println("Perimeter = ");
		System.out.println((4.5 + 7.9) * 2);
	}
}